@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\patoli.ps1" -Action Start
if errorlevel 1 pause
